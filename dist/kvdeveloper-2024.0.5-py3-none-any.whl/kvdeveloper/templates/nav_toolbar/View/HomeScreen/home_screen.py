from View.base_screen import BaseScreenView
from kivymd.uix.boxlayout import MDBoxLayout

class HomeScreenContext(MDBoxLayout):
    pass

class HomeScreenView(BaseScreenView):
    pass