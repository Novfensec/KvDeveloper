from View.base_screen import BaseScreenView

class SampleScreenView(BaseScreenView):
    pass