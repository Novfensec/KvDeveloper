from View.base_screen import BaseScreenView

class LoginScreenView(BaseScreenView):
    pass