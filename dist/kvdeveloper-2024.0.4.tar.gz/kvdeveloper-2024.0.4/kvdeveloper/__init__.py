__app_name__ = "kvdeveloper"
__version__ = "2024.0.4"

(
    SUCCESS,
    DIR_ERROR,
) = range(2)

ERRORS = {
    DIR_ERROR: "config directory error",
}