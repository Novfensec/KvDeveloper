from View.base_screen import BaseScreenView

class HomeScreenView(BaseScreenView):
    pass