from View.SampleScreen.sample_screen import SampleScreenView

screens = {
    'sample screen':{
        'object': SampleScreenView(),
    },
}
